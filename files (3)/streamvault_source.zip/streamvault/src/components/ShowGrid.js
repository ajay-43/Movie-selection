import React, { useRef, useEffect } from 'react';
import ShowCard from './ShowCard';
import { useInfiniteShows } from '../hooks';
import './ShowGrid.css';

export default function ShowGrid({ filter, onShowSelect, title }) {
  const { shows, loading, hasMore, error, loadMore } = useInfiniteShows(filter);
  const sentinelRef = useRef(null);

  // Intersection observer to auto-trigger loadMore
  useEffect(() => {
    const sentinel = sentinelRef.current;
    if (!sentinel) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting && !loading) loadMore(); },
      { rootMargin: '400px' }
    );
    observer.observe(sentinel);
    return () => observer.disconnect();
  }, [loading, loadMore]);

  return (
    <div className="show-grid-container">
      {title && <h2 className="grid-title">{title}</h2>}

      {error && (
        <div className="grid-error">
          <p>⚠ {error}</p>
          <button onClick={loadMore}>Try again</button>
        </div>
      )}

      <div className="show-grid">
        {shows.map(show => (
          <ShowCard key={show.id} show={show} onClick={onShowSelect} />
        ))}
        {loading && Array.from({ length: 12 }).map((_, i) => (
          <div key={`sk-${i}`} className="card-skeleton">
            <div className="skeleton" style={{ aspectRatio: '2/3', borderRadius: 8 }} />
            <div className="skeleton" style={{ height: 13, width: '75%', marginTop: 8, borderRadius: 4 }} />
            <div className="skeleton" style={{ height: 11, width: '50%', marginTop: 5, borderRadius: 4 }} />
          </div>
        ))}
      </div>

      <div ref={sentinelRef} style={{ height: 1 }} />

      {!hasMore && shows.length > 0 && (
        <p className="grid-end">— {shows.length.toLocaleString()} titles loaded —</p>
      )}
    </div>
  );
}
