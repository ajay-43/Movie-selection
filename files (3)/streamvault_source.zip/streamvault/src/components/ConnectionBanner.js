import React from 'react';
import { useApp } from '../context/AppContext';

export default function ConnectionBanner() {
  const { connectionBanner, isOnline } = useApp();

  // Always show offline banner when offline
  const show = connectionBanner || (!isOnline ? 'offline' : null);

  return (
    <div className={`connection-banner ${show || 'online'} ${show ? '' : 'hidden'}`}>
      {show === 'offline'
        ? '⚡ You are offline — showing cached content'
        : '✓ Back online — content updated'}
    </div>
  );
}
