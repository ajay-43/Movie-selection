import React, { useState, useEffect, useRef } from 'react';
import { searchShows } from '../utils/api';
import { useDebounce } from '../hooks';
import ShowCard from './ShowCard';
import './SearchBar.css';

export default function SearchBar({ onSelectShow }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const debouncedQuery = useDebounce(query, 350);
  const inputRef = useRef(null);

  useEffect(() => { inputRef.current?.focus(); }, []);

  useEffect(() => {
    if (!debouncedQuery.trim()) { setResults([]); return; }
    setLoading(true);
    searchShows(debouncedQuery)
      .then(res => {
        // Search by name, id, or year
        const q = debouncedQuery.toLowerCase();
        const filtered = res.filter(({ show }) => {
          if (!show) return false;
          const matchName = show.name?.toLowerCase().includes(q);
          const matchId = String(show.id) === q;
          const matchYear = show.premiered?.startsWith(q);
          return matchName || matchId || matchYear;
        });
        setResults(filtered.slice(0, 8));
      })
      .catch(() => setResults([]))
      .finally(() => setLoading(false));
  }, [debouncedQuery]);

  return (
    <div className="search-container">
      <div className="search-input-wrap">
        <svg className="search-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
        </svg>
        <input
          ref={inputRef}
          type="text"
          className="search-input"
          placeholder="Search titles, ID, or year..."
          value={query}
          onChange={e => setQuery(e.target.value)}
        />
        {loading && <span className="search-spinner" />}
        {query && (
          <button className="search-clear" onClick={() => setQuery('')}>✕</button>
        )}
      </div>

      {results.length > 0 && (
        <div className="search-results animate-slideDown">
          {results.map(({ show }) => (
            <button
              key={show.id}
              className="search-result-item"
              onClick={() => onSelectShow(show)}
            >
              <div className="result-thumb">
                {show.image?.medium ? (
                  <img src={show.image.medium} alt={show.name} loading="lazy" />
                ) : (
                  <div className="result-thumb-placeholder">{show.name?.[0]}</div>
                )}
              </div>
              <div className="result-info">
                <span className="result-name">{show.name}</span>
                <span className="result-meta">
                  {show.type} · {show.premiered?.slice(0,4) || 'N/A'}
                  {show.genres?.[0] && ` · ${show.genres[0]}`}
                </span>
              </div>
              <div className={`result-badge ${show.status === 'Running' ? 'running' : ''}`}>
                {show.status}
              </div>
            </button>
          ))}
        </div>
      )}

      {query && !loading && results.length === 0 && (
        <div className="search-empty animate-fadeIn">
          No results found for "{query}"
        </div>
      )}
    </div>
  );
}
