import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import SearchBar from './SearchBar';
import './Navbar.css';

const NAV_TABS = ['home', 'tv-shows', 'movies', 'video-games'];
const TAB_LABELS = { home: 'Home', 'tv-shows': 'TV Shows', movies: 'Movies', 'video-games': 'Video Games' };

export default function Navbar({ activeTab, onTabChange, onShowSelect }) {
  const { user, signOut } = useApp();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [showSearch, setShowSearch] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', handler, { passive: true });
    return () => window.removeEventListener('scroll', handler);
  }, []);

  return (
    <nav className={`navbar ${scrolled ? 'scrolled' : ''}`}>
      <div className="nav-logo">STREAM<span>VAULT</span></div>

      <div className="nav-tabs">
        {NAV_TABS.map(tab => (
          <button
            key={tab}
            className={`nav-tab ${activeTab === tab ? 'active' : ''}`}
            onClick={() => onTabChange(tab)}
          >
            {TAB_LABELS[tab]}
          </button>
        ))}
      </div>

      <div className="nav-right">
        <button
          className={`nav-icon-btn ${showSearch ? 'active' : ''}`}
          onClick={() => setShowSearch(v => !v)}
          aria-label="Search"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="7"/>
            <line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
        </button>

        <div className="nav-avatar" onClick={() => setMenuOpen(v => !v)}>
          {user?.name?.[0]?.toUpperCase() || 'G'}
          {menuOpen && (
            <div className="avatar-menu">
              <div className="avatar-menu-name">{user?.name}</div>
              {!user?.isGuest && (
                <button onClick={() => { onTabChange('profile'); setMenuOpen(false); }}>
                  My Profile
                </button>
              )}
              <button className="danger" onClick={signOut}>Sign Out</button>
            </div>
          )}
        </div>
      </div>

      {showSearch && (
        <div className="nav-search-overlay animate-slideDown">
          <SearchBar onSelectShow={(show) => { onShowSelect(show); setShowSearch(false); }} />
        </div>
      )}
    </nav>
  );
}
