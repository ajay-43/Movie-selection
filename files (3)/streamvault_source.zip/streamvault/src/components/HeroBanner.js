import React, { useEffect, useState } from 'react';
import { fetchSchedule } from '../utils/api';
import { useApp } from '../context/AppContext';
import './HeroBanner.css';

export default function HeroBanner({ onSelect }) {
  const [show, setShow] = useState(null);
  const [loaded, setLoaded] = useState(false);
  const { isInWatchlist, addToWatchlist, removeFromWatchlist } = useApp();

  useEffect(() => {
    fetchSchedule()
      .then(schedule => {
        // Pick the show with the highest rating from today's schedule
        const sorted = schedule
          .filter(ep => ep.show?.image?.original)
          .sort((a, b) => (b.show.rating?.average || 0) - (a.show.rating?.average || 0));
        if (sorted[0]) setShow(sorted[0].show);
      })
      .catch(() => {
        // Fallback: show a static prompt
        setShow(null);
      });
  }, []);

  if (!show) return <div className="hero-skeleton skeleton" />;

  const inList = isInWatchlist(show.id);
  const bgImg = show.image?.original || show.image?.medium;

  function cleanSummary(html) {
    const text = html?.replace(/<[^>]+>/g, '') || '';
    return text.length > 220 ? text.slice(0, 220) + '…' : text;
  }

  return (
    <div className={`hero ${loaded ? 'hero--loaded' : ''}`}>
      {bgImg && (
        <img
          className="hero-bg"
          src={bgImg}
          alt=""
          onLoad={() => setLoaded(true)}
          aria-hidden="true"
        />
      )}
      <div className="hero-gradient" />

      <div className="hero-content">
        <div className="hero-eyebrow">TODAY'S TOP SHOW</div>
        <h1 className="hero-title">{show.name}</h1>

        <div className="hero-badges">
          {show.rating?.average && (
            <span className="hero-badge gold">★ {show.rating.average}</span>
          )}
          {show.premiered && (
            <span className="hero-badge">{show.premiered.slice(0, 4)}</span>
          )}
          {show.genres?.slice(0, 2).map(g => (
            <span key={g} className="hero-badge">{g}</span>
          ))}
          {show.status === 'Running' && (
            <span className="hero-badge green">● Running</span>
          )}
        </div>

        <p className="hero-summary">{cleanSummary(show.summary)}</p>

        <div className="hero-actions">
          <button className="hero-btn primary" onClick={() => onSelect(show)}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
              <polygon points="5,3 19,12 5,21" />
            </svg>
            Play
          </button>
          <button
            className={`hero-btn secondary ${inList ? 'active' : ''}`}
            onClick={() => inList ? removeFromWatchlist(show.id) : addToWatchlist(show)}
          >
            {inList ? '✓ In My List' : '+ My List'}
          </button>
          <button className="hero-btn ghost" onClick={() => onSelect(show)}>
            More Info
          </button>
        </div>
      </div>
    </div>
  );
}
