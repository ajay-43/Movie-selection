import React, { useEffect, useState } from 'react';
import { fetchShowById } from '../utils/api';
import { useApp } from '../context/AppContext';
import './ShowModal.css';

export default function ShowModal({ show, onClose }) {
  const [details, setDetails] = useState(null);
  const [loading, setLoading] = useState(true);
  const { isInWatchlist, addToWatchlist, removeFromWatchlist, addToHistory } = useApp();
  const inList = isInWatchlist(show.id);

  useEffect(() => {
    // Prevent body scroll
    document.body.style.overflow = 'hidden';
    addToHistory(show);
    fetchShowById(show.id)
      .then(setDetails)
      .catch(() => setDetails(show))
      .finally(() => setLoading(false));
    return () => { document.body.style.overflow = ''; };
  }, [show.id]);

  useEffect(() => {
    const handler = e => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [onClose]);

  const d = details || show;
  const bgImg = d.image?.original || d.image?.medium;
  const rating = d.rating?.average;
  const cast = details?._embedded?.cast?.slice(0, 8) || [];
  const episodes = details?._embedded?.episodes || [];
  const seasonCount = episodes.length > 0
    ? Math.max(...episodes.map(e => e.season))
    : null;

  function cleanSummary(html) {
    return html?.replace(/<[^>]+>/g, '') || 'No summary available.';
  }

  return (
    <div className="modal-backdrop" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal animate-scaleIn">
        {/* Hero */}
        <div className="modal-hero" style={{ backgroundImage: bgImg ? `url(${bgImg})` : 'none' }}>
          <div className="modal-hero-gradient" />
          <button className="modal-close" onClick={onClose} aria-label="Close">✕</button>
          <div className="modal-hero-content">
            <h2 className="modal-title">{d.name}</h2>
            <div className="modal-badges">
              {rating && <span className="badge gold">★ {rating}</span>}
              {d.premiered && <span className="badge">{d.premiered.slice(0,4)}</span>}
              {seasonCount && <span className="badge">{seasonCount} Season{seasonCount !== 1 ? 's' : ''}</span>}
              {d.status && <span className={`badge ${d.status === 'Running' ? 'green' : ''}`}>{d.status}</span>}
              {d.language && <span className="badge">{d.language}</span>}
            </div>
            <div className="modal-actions">
              <button className="modal-btn primary" onClick={() => addToHistory(show)}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><polygon points="5,3 19,12 5,21"/></svg>
                Play
              </button>
              <button
                className={`modal-btn secondary ${inList ? 'active' : ''}`}
                onClick={() => inList ? removeFromWatchlist(show.id) : addToWatchlist(show)}
              >
                {inList ? '✓ In My List' : '+ My List'}
              </button>
            </div>
          </div>
        </div>

        {/* Details */}
        <div className="modal-body">
          {loading ? (
            <div className="modal-loading">
              <div className="skeleton" style={{ height: 16, width: '80%', marginBottom: 8 }} />
              <div className="skeleton" style={{ height: 16, width: '60%' }} />
            </div>
          ) : (
            <>
              <div className="modal-two-col">
                <div className="modal-summary">
                  <p>{cleanSummary(d.summary)}</p>
                </div>
                <div className="modal-meta-list">
                  {d.genres?.length > 0 && (
                    <div className="meta-row">
                      <span className="meta-label">Genres:</span>
                      <span>{d.genres.join(', ')}</span>
                    </div>
                  )}
                  {d.network?.name && (
                    <div className="meta-row">
                      <span className="meta-label">Network:</span>
                      <span>{d.network.name}</span>
                    </div>
                  )}
                  {d.type && (
                    <div className="meta-row">
                      <span className="meta-label">Type:</span>
                      <span>{d.type}</span>
                    </div>
                  )}
                  {d.averageRuntime && (
                    <div className="meta-row">
                      <span className="meta-label">Runtime:</span>
                      <span>{d.averageRuntime} min</span>
                    </div>
                  )}
                  {d.schedule?.days?.length > 0 && (
                    <div className="meta-row">
                      <span className="meta-label">Schedule:</span>
                      <span>{d.schedule.days.join(', ')} at {d.schedule.time || '?'}</span>
                    </div>
                  )}
                </div>
              </div>

              {cast.length > 0 && (
                <div className="modal-cast">
                  <h3 className="section-label">Cast</h3>
                  <div className="cast-grid">
                    {cast.map(({ person, character }) => (
                      <div key={person.id} className="cast-item">
                        <div className="cast-img">
                          {person.image?.medium ? (
                            <img src={person.image.medium} alt={person.name} loading="lazy" />
                          ) : (
                            <div className="cast-placeholder">{person.name?.[0]}</div>
                          )}
                        </div>
                        <p className="cast-name">{person.name}</p>
                        <p className="cast-char">{character.name}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {episodes.length > 0 && (
                <div className="modal-episodes">
                  <h3 className="section-label">Episodes — {episodes.length} total</h3>
                  <div className="episodes-grid">
                    {episodes.slice(0, 6).map(ep => (
                      <div key={ep.id} className="episode-item">
                        {ep.image?.medium && (
                          <img src={ep.image.medium} alt={ep.name} loading="lazy" />
                        )}
                        <div className="ep-info">
                          <span className="ep-num">S{ep.season}E{String(ep.number).padStart(2,'0')}</span>
                          <span className="ep-name">{ep.name}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
