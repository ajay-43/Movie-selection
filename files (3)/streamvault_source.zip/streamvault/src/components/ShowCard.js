import React, { useState } from 'react';
import { useIntersection } from '../hooks';
import { useApp } from '../context/AppContext';
import './ShowCard.css';

export default function ShowCard({ show, onClick }) {
  const [ref, isVisible] = useIntersection();
  const [imgLoaded, setImgLoaded] = useState(false);
  const { isInWatchlist, addToWatchlist, removeFromWatchlist, addToHistory } = useApp();

  const inList = isInWatchlist(show.id);
  const imgSrc = show.image?.medium || show.image?.original || null;
  const rating = show.rating?.average;
  const year = show.premiered?.slice(0, 4);

  function handleClick(e) {
    e.stopPropagation();
    addToHistory(show);
    onClick?.(show);
  }

  function handleWatchlist(e) {
    e.stopPropagation();
    if (inList) removeFromWatchlist(show.id);
    else addToWatchlist(show);
  }

  return (
    <div className="show-card" ref={ref} onClick={handleClick}>
      <div className="card-thumb">
        {isVisible ? (
          <>
            {!imgLoaded && <div className="skeleton card-img-skeleton" />}
            {imgSrc ? (
              <img
                src={imgSrc}
                alt={show.name}
                loading="lazy"
                onLoad={() => setImgLoaded(true)}
                style={{ opacity: imgLoaded ? 1 : 0 }}
              />
            ) : (
              <div className="card-no-img">
                <span>{show.name?.[0] || '?'}</span>
              </div>
            )}
          </>
        ) : (
          <div className="skeleton card-img-skeleton" />
        )}

        {/* Hover overlay */}
        <div className="card-overlay">
          <button className="card-play-btn" onClick={handleClick} aria-label="View show">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
              <polygon points="5,3 19,12 5,21"/>
            </svg>
          </button>
          <button
            className={`card-list-btn ${inList ? 'active' : ''}`}
            onClick={handleWatchlist}
            aria-label={inList ? 'Remove from watchlist' : 'Add to watchlist'}
          >
            {inList ? '✓' : '+'}
          </button>
        </div>

        {/* Rating badge */}
        {rating && <div className="card-rating">★ {rating}</div>}
      </div>

      <div className="card-info">
        <p className="card-title">{show.name}</p>
        <p className="card-meta">
          {year && <span>{year}</span>}
          {show.genres?.[0] && <span>{show.genres[0]}</span>}
        </p>
      </div>
    </div>
  );
}
