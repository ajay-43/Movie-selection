import { useState, useEffect, useRef, useCallback } from 'react';
import { fetchShowsBatch } from '../utils/api';

// Debounce hook — prevents unnecessary server calls
export function useDebounce(value, delay = 350) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);
  return debounced;
}

// Intersection observer for lazy loading
export function useIntersection(options = {}) {
  const ref = useRef(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setIsVisible(true);
        observer.unobserve(el); // fire once, then stop observing to prevent memory leaks
      }
    }, { threshold: 0.1, rootMargin: '200px', ...options });
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return [ref, isVisible];
}

// Infinite scroll / paginated shows loader
export function useInfiniteShows(filter = null) {
  const [shows, setShows] = useState([]);
  const [page, setPage] = useState(0);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [error, setError] = useState(null);

  const loadMore = useCallback(async () => {
    if (loading || !hasMore) return;
    setLoading(true);
    setError(null);
    try {
      const batch = await fetchShowsBatch(page, 3);
      if (batch.length === 0) {
        setHasMore(false);
      } else {
        const filtered = filter ? batch.filter(filter) : batch;
        setShows(prev => {
          // Deduplicate by id to prevent memory bloat
          const existingIds = new Set(prev.map(s => s.id));
          const newOnes = filtered.filter(s => !existingIds.has(s.id));
          return [...prev, ...newOnes];
        });
        setPage(prev => prev + 3);
        if (batch.length < 250) setHasMore(false);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [page, loading, hasMore, filter]);

  // Auto-load first batch
  useEffect(() => {
    loadMore();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return { shows, loading, hasMore, error, loadMore };
}

// Previous value hook (for transition comparisons)
export function usePrevious(value) {
  const ref = useRef();
  useEffect(() => { ref.current = value; });
  return ref.current;
}
