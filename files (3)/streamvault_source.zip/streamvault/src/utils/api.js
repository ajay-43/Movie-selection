// TVMaze REST API: https://api.tvmaze.com
const BASE = 'https://api.tvmaze.com';

// In-memory cache to prevent memory leaks and unnecessary re-renders
const cache = new Map();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

const OFFLINE_KEY = 'sv_offline_cache';

// Persist critical data for offline use
function saveOfflineCache(key, data) {
  try {
    const existing = JSON.parse(sessionStorage.getItem(OFFLINE_KEY) || '{}');
    existing[key] = { data, ts: Date.now() };
    sessionStorage.setItem(OFFLINE_KEY, JSON.stringify(existing));
  } catch (_) {}
}

function getOfflineCache(key) {
  try {
    const existing = JSON.parse(sessionStorage.getItem(OFFLINE_KEY) || '{}');
    return existing[key]?.data || null;
  } catch { return null; }
}

async function apiFetch(url, cacheKey, persist = false) {
  // Check memory cache first
  const cached = cache.get(cacheKey);
  if (cached && Date.now() - cached.ts < CACHE_TTL) {
    return cached.data;
  }

  // Check offline cache
  if (!navigator.onLine) {
    const offlineData = getOfflineCache(cacheKey);
    if (offlineData) return offlineData;
    throw new Error('You are offline and no cached data is available.');
  }

  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();

    // Store in memory cache
    cache.set(cacheKey, { data, ts: Date.now() });
    // Limit cache size to prevent memory leaks
    if (cache.size > 500) {
      const firstKey = cache.keys().next().value;
      cache.delete(firstKey);
    }

    if (persist) saveOfflineCache(cacheKey, data);

    return data;
  } catch (err) {
    const offlineData = getOfflineCache(cacheKey);
    if (offlineData) return offlineData;
    throw err;
  }
}

// Fetch paginated shows (10,000 items via multiple pages)
export async function fetchShowsPage(page = 0) {
  return apiFetch(`${BASE}/shows?page=${page}`, `shows_p${page}`, page < 5);
}

// Fetch all shows up to a page limit
export async function fetchShowsBatch(startPage = 0, count = 5) {
  const promises = [];
  for (let i = startPage; i < startPage + count; i++) {
    promises.push(fetchShowsPage(i).catch(() => []));
  }
  const results = await Promise.all(promises);
  return results.flat();
}

// Search shows — used with debounce
export async function searchShows(query) {
  if (!query.trim()) return [];
  return apiFetch(`${BASE}/search/shows?q=${encodeURIComponent(query)}`, `search_${query}`);
}

// Get show details
export async function fetchShowById(id) {
  return apiFetch(`${BASE}/shows/${id}?embed[]=episodes&embed[]=cast`, `show_${id}`, true);
}

// Get today's schedule
export async function fetchSchedule() {
  const today = new Date().toISOString().split('T')[0];
  return apiFetch(`${BASE}/schedule?country=US&date=${today}`, `schedule_${today}`, true);
}

// Filter helpers
export function isMovie(show) {
  return show?.type === 'Animation' || show?.genres?.includes('Animation')
    ? false : show?.type === 'Documentary' || show?.averageRuntime >= 60;
}

export function isTVShow(show) {
  return show?.type === 'Scripted' || show?.type === 'Reality' || show?.type === 'Talk Show' || show?.type === 'Game Show';
}

export function isVideoGame(show) {
  return show?.genres?.includes('Science-Fiction') && show?.network?.name?.includes('Game');
}
