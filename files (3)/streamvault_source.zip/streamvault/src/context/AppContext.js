import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

const AppContext = createContext();

export function AppProvider({ children }) {
  const [user, setUser] = useState(null); // null = signed out
  const [watchlist, setWatchlist] = useState(() => {
    try { return JSON.parse(localStorage.getItem('sv_watchlist') || '[]'); } catch { return []; }
  });
  const [watchHistory, setWatchHistory] = useState(() => {
    try { return JSON.parse(localStorage.getItem('sv_history') || '[]'); } catch { return []; }
  });
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [connectionBanner, setConnectionBanner] = useState(null); // 'online' | 'offline' | null

  // Online/offline detection
  useEffect(() => {
    let bannerTimer;
    const handleOnline = () => {
      setIsOnline(true);
      setConnectionBanner('online');
      bannerTimer = setTimeout(() => setConnectionBanner(null), 3000);
    };
    const handleOffline = () => {
      setIsOnline(false);
      setConnectionBanner('offline');
    };
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearTimeout(bannerTimer);
    };
  }, []);

  // Persist watchlist/history
  useEffect(() => {
    localStorage.setItem('sv_watchlist', JSON.stringify(watchlist));
  }, [watchlist]);

  useEffect(() => {
    localStorage.setItem('sv_history', JSON.stringify(watchHistory));
  }, [watchHistory]);

  const addToWatchlist = useCallback((show) => {
    setWatchlist(prev => {
      if (prev.find(s => s.id === show.id)) return prev;
      return [show, ...prev];
    });
  }, []);

  const removeFromWatchlist = useCallback((id) => {
    setWatchlist(prev => prev.filter(s => s.id !== id));
  }, []);

  const isInWatchlist = useCallback((id) => watchlist.some(s => s.id === id), [watchlist]);

  const addToHistory = useCallback((show) => {
    setWatchHistory(prev => {
      const filtered = prev.filter(s => s.id !== show.id);
      return [{ ...show, watchedAt: Date.now() }, ...filtered].slice(0, 100);
    });
  }, []);

  const signIn = useCallback((userData) => setUser(userData), []);
  const signOut = useCallback(() => setUser(null), []);

  return (
    <AppContext.Provider value={{
      user, signIn, signOut,
      watchlist, addToWatchlist, removeFromWatchlist, isInWatchlist,
      watchHistory, addToHistory,
      isOnline, connectionBanner
    }}>
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => useContext(AppContext);
