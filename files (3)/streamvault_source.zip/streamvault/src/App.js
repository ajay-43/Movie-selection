import React, { useState, useCallback } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import SignIn from './pages/SignIn';
import HomePage from './pages/HomePage';
import CategoryPage from './pages/CategoryPage';
import ProfilePage from './pages/ProfilePage';
import Navbar from './components/Navbar';
import ShowModal from './components/ShowModal';
import ConnectionBanner from './components/ConnectionBanner';

function AppInner() {
  const { user } = useApp();
  const [tab, setTab] = useState('home');
  const [selectedShow, setSelectedShow] = useState(null);
  const [prevTab, setPrevTab] = useState(null);

  const handleTabChange = useCallback((newTab) => {
    setPrevTab(tab);
    setTab(newTab);
  }, [tab]);

  const handleShowSelect = useCallback((show) => {
    setSelectedShow(show);
  }, []);

  const handleModalClose = useCallback(() => {
    setSelectedShow(null);
  }, []);

  if (!user) return <SignIn />;

  const renderPage = () => {
    const key = tab; // key forces re-mount + re-animation on tab change
    switch (tab) {
      case 'home':
        return <HomePage key={key} onShowSelect={handleShowSelect} />;
      case 'tv-shows':
      case 'movies':
      case 'video-games':
        return <CategoryPage key={key} category={tab} onShowSelect={handleShowSelect} />;
      case 'profile':
        return <ProfilePage key={key} onShowSelect={handleShowSelect} />;
      default:
        return <HomePage key={key} onShowSelect={handleShowSelect} />;
    }
  };

  return (
    <>
      <ConnectionBanner />
      <Navbar
        activeTab={tab}
        onTabChange={handleTabChange}
        onShowSelect={handleShowSelect}
      />
      <main className="app-main animate-fadeIn" key={tab}>
        {renderPage()}
      </main>
      {selectedShow && (
        <ShowModal show={selectedShow} onClose={handleModalClose} />
      )}
    </>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppInner />
    </AppProvider>
  );
}
