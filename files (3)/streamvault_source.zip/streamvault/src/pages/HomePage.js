import React, { useState, useEffect } from 'react';
import HeroBanner from '../components/HeroBanner';
import ShowGrid from '../components/ShowGrid';
import ShowCard from '../components/ShowCard';
import { fetchShowsBatch } from '../utils/api';
import './HomePage.css';

// Quick horizontal row
function ShowRow({ title, shows, onSelect }) {
  if (!shows.length) return null;
  return (
    <div className="show-row">
      <h2 className="row-title">{title}</h2>
      <div className="row-scroll">
        {shows.map(show => (
          <div key={show.id} className="row-item">
            <ShowCard show={show} onClick={onSelect} />
          </div>
        ))}
      </div>
    </div>
  );
}

export default function HomePage({ onShowSelect }) {
  const [featured, setFeatured] = useState([]);
  const [topRated, setTopRated] = useState([]);
  const [trending, setTrending] = useState([]);

  useEffect(() => {
    fetchShowsBatch(0, 2).then(shows => {
      const withImages = shows.filter(s => s.image?.medium);
      const sorted = [...withImages].sort((a, b) => (b.rating?.average || 0) - (a.rating?.average || 0));
      setTopRated(sorted.slice(0, 20));
      setFeatured(sorted.slice(20, 40));
      setTrending(shows.filter(s => s.image?.medium && s.status === 'Running').slice(0, 20));
    }).catch(() => {});
  }, []);

  return (
    <div className="home-page">
      <HeroBanner onSelect={onShowSelect} />

      <div className="home-rows">
        <ShowRow title="Top Rated" shows={topRated} onSelect={onShowSelect} />
        <ShowRow title="Currently Running" shows={trending} onSelect={onShowSelect} />
        <ShowRow title="Featured" shows={featured} onSelect={onShowSelect} />
      </div>

      <div className="home-all">
        <ShowGrid
          title="All Titles"
          onShowSelect={onShowSelect}
        />
      </div>
    </div>
  );
}
