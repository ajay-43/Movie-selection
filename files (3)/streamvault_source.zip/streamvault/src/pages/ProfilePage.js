import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import ShowCard from '../components/ShowCard';
import './ProfilePage.css';

export default function ProfilePage({ onShowSelect }) {
  const { user, signOut, watchlist, watchHistory, removeFromWatchlist } = useApp();
  const [tab, setTab] = useState('watchlist');

  const items = tab === 'watchlist' ? watchlist : watchHistory;

  return (
    <div className="profile-page animate-fadeIn">
      {/* Profile Header */}
      <div className="profile-header">
        <div className="profile-avatar">
          {user?.name?.[0]?.toUpperCase() || 'G'}
        </div>
        <div className="profile-info">
          <h2 className="profile-name">{user?.name}</h2>
          <p className="profile-email">{user?.isGuest ? 'Guest Account' : user?.email}</p>
          <div className="profile-stats">
            <div className="stat">
              <span className="stat-num">{watchlist.length}</span>
              <span className="stat-label">Watchlist</span>
            </div>
            <div className="stat">
              <span className="stat-num">{watchHistory.length}</span>
              <span className="stat-label">Watched</span>
            </div>
          </div>
        </div>
        <button className="signout-btn" onClick={signOut}>Sign Out</button>
      </div>

      {/* Tabs */}
      <div className="profile-tabs">
        <button
          className={`ptab ${tab === 'watchlist' ? 'active' : ''}`}
          onClick={() => setTab('watchlist')}
        >
          My Watchlist
        </button>
        <button
          className={`ptab ${tab === 'history' ? 'active' : ''}`}
          onClick={() => setTab('history')}
        >
          Watch History
        </button>
      </div>

      {/* Content */}
      <div className="profile-content">
        {items.length === 0 ? (
          <div className="profile-empty">
            <p className="empty-icon">{tab === 'watchlist' ? '🎬' : '📺'}</p>
            <p>{tab === 'watchlist' ? 'Your watchlist is empty.' : 'No watch history yet.'}</p>
            <p className="empty-sub">Browse titles and click + to add them here.</p>
          </div>
        ) : (
          <div className="profile-grid">
            {items.map(show => (
              <div key={show.id} className="profile-card-wrap">
                <ShowCard show={show} onClick={onShowSelect} />
                {tab === 'watchlist' && (
                  <button
                    className="remove-btn"
                    onClick={() => removeFromWatchlist(show.id)}
                    title="Remove"
                  >✕</button>
                )}
                {tab === 'history' && show.watchedAt && (
                  <p className="watched-at">
                    {new Date(show.watchedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
