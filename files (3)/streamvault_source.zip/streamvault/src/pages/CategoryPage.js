import React, { useMemo } from 'react';
import ShowGrid from '../components/ShowGrid';

const FILTERS = {
  'tv-shows': show =>
    ['Scripted', 'Reality', 'Talk Show', 'Game Show', 'Variety', 'Panel Show', 'Documentary'].includes(show.type),
  'movies': show =>
    show.type === 'Documentary' || (show.averageRuntime && show.averageRuntime >= 60 && show.genres?.includes('Drama')),
  'video-games': show =>
    show.genres?.some(g => ['Science-Fiction', 'Fantasy', 'Action', 'Adventure'].includes(g)) &&
    show.type === 'Animation',
};

const TITLES = {
  'tv-shows': 'TV Shows',
  'movies': 'Movies',
  'video-games': 'Video Games',
};

export default function CategoryPage({ category, onShowSelect }) {
  const filter = useMemo(() => FILTERS[category] || null, [category]);

  return (
    <div style={{ paddingTop: 'calc(var(--nav-height) + 32px)' }}>
      <ShowGrid
        key={category}
        filter={filter}
        title={TITLES[category] || category}
        onShowSelect={onShowSelect}
      />
    </div>
  );
}
