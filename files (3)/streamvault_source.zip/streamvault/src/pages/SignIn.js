import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import './SignIn.css';

export default function SignIn() {
  const { signIn } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [mode, setMode] = useState('signin'); // signin | signup

  async function handleSubmit(e) {
    e.preventDefault();
    if (!email || !password) { setError('Please fill in all fields.'); return; }
    setLoading(true);
    setError('');
    // Simulate auth delay
    await new Promise(r => setTimeout(r, 900));
    signIn({ email, name: email.split('@')[0], avatar: null });
    setLoading(false);
  }

  function handleGuest() {
    signIn({ email: 'guest', name: 'Guest User', avatar: null, isGuest: true });
  }

  return (
    <div className="signin-bg">
      <div className="signin-overlay" />
      <div className="signin-logo">STREAM<span>VAULT</span></div>

      <div className="signin-card animate-scaleIn">
        <h2 className="signin-title">{mode === 'signin' ? 'Sign In' : 'Create Account'}</h2>

        <form onSubmit={handleSubmit} className="signin-form">
          <div className="field">
            <input
              type="email" placeholder="Email address"
              value={email} onChange={e => setEmail(e.target.value)}
              autoComplete="email"
            />
          </div>
          <div className="field">
            <input
              type="password" placeholder="Password"
              value={password} onChange={e => setPassword(e.target.value)}
              autoComplete={mode === 'signin' ? 'current-password' : 'new-password'}
            />
          </div>
          {error && <p className="signin-error">{error}</p>}
          <button type="submit" className="btn-primary" disabled={loading}>
            {loading ? <span className="spinner" /> : mode === 'signin' ? 'Sign In' : 'Create Account'}
          </button>
        </form>

        <div className="signin-divider"><span>or</span></div>

        <button className="btn-guest" onClick={handleGuest}>
          Continue as Guest
        </button>

        <p className="signin-switch">
          {mode === 'signin' ? "Don't have an account? " : 'Already have an account? '}
          <button onClick={() => setMode(mode === 'signin' ? 'signup' : 'signin')}>
            {mode === 'signin' ? 'Sign up' : 'Sign in'}
          </button>
        </p>
      </div>

      <p className="signin-disclaimer">
        By continuing, you agree to our Terms of Use and Privacy Policy.
      </p>
    </div>
  );
}
